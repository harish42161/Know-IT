namespace BOL;

public class Item {
    public  Product theProduct{get;set;}  //has a relationship

    public int Quantity{get;set;}
}