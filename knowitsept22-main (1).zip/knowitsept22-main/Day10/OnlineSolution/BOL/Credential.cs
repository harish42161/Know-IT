namespace BOL;
public class Credential{
    public string Email{get;set;}
    public string Password{get;set;}
}