﻿

Console.WriteLine("Hello, World!");
var obj= new { FirstName="Ravi", 
	       LastName="Tambade"};

Console.WriteLine(obj.FirstName + "   " + obj.LastName);
