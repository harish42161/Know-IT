namespace BOL;

public class Cart{
    public List<Item> Items=new List<Item>();

}